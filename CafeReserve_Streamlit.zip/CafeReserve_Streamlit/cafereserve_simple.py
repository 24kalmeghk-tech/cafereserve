# CafeReserve AI - Beginner Version
# One simple program covering Practicals 1 to 7 on cafe booking data.
# Run:  python cafereserve_simple.py

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, GridSearchCV, RandomizedSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier, RandomForestClassifier
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

np.random.seed(42)

# ---------- STEP 0: Make a sample (synthetic) cafe dataset ----------
n = 1000
df = pd.DataFrame({
    "customer_id": np.random.randint(1, 101, n),
    "hour": np.random.randint(9, 22, n),            # 9 AM to 9 PM
    "temp": np.random.normal(28, 5, n).round(1),    # temperature
    "party_size": np.random.randint(1, 9, n),       # people per booking
    "advance_days": np.random.randint(0, 15, n),    # booked how many days before
    "past_visits": np.random.randint(0, 20, n),
    "spend": np.random.normal(600, 150, n).round(0),
})
# no_show = 1 means customer did not come
df["no_show"] = ((df.advance_days * 0.05 - df.past_visits * 0.02 + np.random.rand(n)) > 0.7).astype(int)
df.loc[:30, "temp"] = np.nan                        # add some missing values
df.to_csv("cafe_reservations.csv", index=False)

# ---------- PRACTICAL 1: Missing values + EDA ----------
print("Shape:", df.shape)
print("Missing values:\n", df.isnull().sum())
df["temp"] = df["temp"].fillna(df["temp"].median())   # fill with median

df.groupby("hour").size().plot(kind="bar", title="Bookings by Hour")
plt.savefig("p1_bookings_by_hour.png"); plt.close()

# ---------- PRACTICAL 2: Linear Regression (predict party size) ----------
# Simple LR: one feature
X1 = df[["temp"]]
y = df["party_size"]
X_train, X_test, y_train, y_test = train_test_split(X1, y, test_size=0.2, random_state=42)
simple = LinearRegression().fit(X_train, y_train)
p1 = simple.predict(X_test)

# Multiple LR: many features
X2 = df[["temp", "hour", "advance_days", "past_visits", "spend"]]
X_train2, X_test2, y_train2, y_test2 = train_test_split(X2, y, test_size=0.2, random_state=42)
multi = LinearRegression().fit(X_train2, y_train2)
p2 = multi.predict(X_test2)

for name, pred in [("Simple LR", p1), ("Multiple LR", p2)]:
    mse = mean_squared_error(y_test, pred)
    print(name, "MAE:", round(mean_absolute_error(y_test, pred), 2), "MSE:", round(mse, 2),
          "RMSE:", round(mse ** 0.5, 2), "R2:", round(r2_score(y_test, pred), 3))

plt.scatter(X_test, y_test); plt.plot(X_test, p1, color="red")
plt.title("Simple Linear Regression"); plt.savefig("p2_regression_line.png"); plt.close()

# ---------- PRACTICAL 3: Classification (predict no-show) ----------
features = ["hour", "temp", "party_size", "advance_days", "past_visits", "spend"]
X = StandardScaler().fit_transform(df[features])     # scale the data
t = df["no_show"]
Xtr, Xte, ytr, yte = train_test_split(X, t, test_size=0.25, random_state=42)

models = {"Logistic": LogisticRegression(), "KNN": KNeighborsClassifier(), "Naive Bayes": GaussianNB()}
for name, m in models.items():
    pred = m.fit(Xtr, ytr).predict(Xte)
    print(name, "Acc:", round(accuracy_score(yte, pred), 3), "Prec:", round(precision_score(yte, pred, zero_division=0), 3),
          "Recall:", round(recall_score(yte, pred), 3), "F1:", round(f1_score(yte, pred), 3))

# ---------- PRACTICAL 4: K-Means (group customers) ----------
cust = df.groupby("customer_id")[["spend", "past_visits", "advance_days"]].mean()
Xc = StandardScaler().fit_transform(cust)

wcss = []
for k in range(1, 9):
    wcss.append(KMeans(n_clusters=k, n_init=10, random_state=42).fit(Xc).inertia_)
plt.plot(range(1, 9), wcss, marker="o"); plt.title("Elbow Method")
plt.savefig("p4_elbow.png"); plt.close()

cust["cluster"] = KMeans(n_clusters=3, n_init=10, random_state=42).fit_predict(Xc)
print(cust.groupby("cluster").mean())

# ---------- PRACTICAL 5: GMM (soft clustering) ----------
gmm = GaussianMixture(n_components=3, random_state=42).fit(Xc)
cust["gmm_cluster"] = gmm.predict(Xc)
print("GMM probabilities (first 3 customers):\n", gmm.predict_proba(Xc)[:3].round(2))
points = PCA(n_components=2).fit_transform(Xc)       # shrink to 2D for plotting
plt.scatter(points[:, 0], points[:, 1], c=cust["gmm_cluster"])
plt.title("GMM Clusters"); plt.savefig("p5_gmm.png"); plt.close()
print(cust.groupby("gmm_cluster").head(5))           # first 5 customers in each cluster

# ---------- PRACTICAL 6: Bagging and Random Forest ----------
for trees in [5, 10, 50, 100]:
    bag = BaggingClassifier(DecisionTreeClassifier(), n_estimators=trees, random_state=42).fit(Xtr, ytr)
    print("Bagging with", trees, "trees -> accuracy:", round(bag.score(Xte, yte), 3))

dt = DecisionTreeClassifier(random_state=42).fit(Xtr, ytr)
rf = RandomForestClassifier(n_estimators=100, class_weight="balanced", random_state=42).fit(Xtr, ytr)
print("Decision Tree accuracy:", round(dt.score(Xte, yte), 3))
print("Random Forest accuracy:", round(rf.score(Xte, yte), 3))

# ---------- PRACTICAL 7: Cross-validation + tuning ----------
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(RandomForestClassifier(random_state=42), Xtr, ytr, cv=skf)
print("5-fold CV mean:", scores.mean().round(3), "std:", scores.std().round(3))

params = {"n_estimators": [50, 100], "max_depth": [None, 5, 10]}
grid = GridSearchCV(RandomForestClassifier(random_state=42), params, cv=5).fit(Xtr, ytr)
rand = RandomizedSearchCV(RandomForestClassifier(random_state=42), params, n_iter=4, cv=5, random_state=42).fit(Xtr, ytr)
print("GridSearch best:", grid.best_params_, round(grid.best_score_, 3))
print("RandomSearch best:", rand.best_params_, round(rand.best_score_, 3))

best = grid.best_estimator_
imp = pd.Series(best.feature_importances_, index=features).sort_values()
imp.plot(kind="barh", title="Feature Importance"); plt.tight_layout()
plt.savefig("p7_importance.png"); plt.close()
print("Top 3 features:", list(imp.index[-3:]))
